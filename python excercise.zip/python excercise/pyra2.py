for i in range(0,5,1):
       for k in range(1,5-i-1,1):
              print(end =" ")
       for j in range(0,2*i+1,1):
              print(" * ", end=" ")
       print("\n")
