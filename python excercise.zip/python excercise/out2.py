for i in range(10):
       if i == 5:
              break
       else:
              print(i)
else:
       print("Here")
