n1=10
n2=20
if(n1>n2):
       print("{}is greater than {}".format(n1,n2))
else:
      print("{}is greater than {}".format(n2,n1))
