d = {0: 'a', 1: 'b', 2: 'c'}
for i in d:
       print(d[i])
