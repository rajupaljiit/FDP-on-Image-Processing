n1=10
n2=20
n3=45
if(n1>n2):
       if(n1>n3):
              print("{}is largest".format(n1))
elif(n2>n3):
      print("{}is largest".format(n2))
else:
       print("{}is largest".format(n3))

