print("""Twinkle, twinkle, little star, \n\tHow I wonder what you are!
      \t\tUp above the world so high, \n\t\tLike a diamond in the sky.
      Twinkle, twinkle, little star, \n\tHow I wonder what you are!""")
