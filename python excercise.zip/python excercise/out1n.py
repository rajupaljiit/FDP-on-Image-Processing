i = 2
while True:
       if i%3 == 0:
              break
       print(i)
       i += 2
