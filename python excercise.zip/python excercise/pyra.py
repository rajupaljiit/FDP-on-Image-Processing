for i in range(1,5,1):
    for j in range(1,i,1):
        print("*", end='')
    print("\n")
