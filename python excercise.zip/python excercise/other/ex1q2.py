fname="Avinash"
lname="Pandey"

print(lname+ " " +fname)
